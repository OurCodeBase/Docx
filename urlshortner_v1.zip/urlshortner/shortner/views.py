from django.shortcuts import render,redirect
from django.http import HttpResponsePermanentRedirect
from threading import Timer
import os
import random
import string
import json

# Create your views here.

# Add That Random word.
def add_rand_word(word):
	module_dir=os.path.dirname(__file__)
	file_path=os.path.join(module_dir,'wordlist.md')
	random_file=open(file_path,'r')
	read_random_word_file=random_file.read()
	random_list=list(map(str,read_random_word_file.split()))
	random_list.remove(word)
	add_word=open(file_path,'w')
	for items in random_list:
		add_word.write(items+'\n')

# Remove That Random word.
def del_rand_word(del_rand_str):
	module_dir=os.path.dirname(__file__)
	file_path=os.path.join(module_dir,'wordlist.md')
	random_file=open(file_path,'r')
	read_random_word_file=random_file.read()
	random_list=list(map(str,read_random_word_file.split()))
	random_list.remove(del_rand_str)
	add_file=open(file_path,'w')
	for items in random_list:
		add_file.write(items+'\n')

# Randomise Words
def randomise():
	module_dir=os.path.dirname(__file__)
	file_path=os.path.join(module_dir,'wordlist.md')
	random_file=open(file_path,'r')
	read_random_word_file=random_file.read()
	random_list=list(map(str,read_random_word_file.split()))
	random_word=random.choice(random_list)
	return random_word

# Randomise Dynamic Random Urls
def random_link():
	lower=string.ascii_lowercase
	upper=string.ascii_uppercase
	num=string.digits
	symbols=string.punctuation
	all=lower+upper+num
	temp=random.sample(all,16)
	rand_link="".join(temp)
	return rand_link
	
# Add file to json
def add_json_data(key,value):
	module_dir=os.path.dirname(__file__)
	file_path=os.path.join(module_dir,'workpost.json')
	listObj={}
	json_file=open(file_path,'r')
	listObj=json.load(json_file)
	dictionary={"{}".format(key):"{}".format(value)}
	listObj=dict(listObj)
	listObj.update(dictionary)
	file_add=open(file_path,'w')
	json.dump(listObj,file_add)
	
# Remove Json link after time
def del_json_data(key):
	module_dir=os.path.dirname(__file__)
	file_path=os.path.join(module_dir,'workpost.json')
	listObj={}
	json_file=open(file_path,'r')
	listObj=json.load(json_file)
	del listObj["{}".format(key)]
	file_del=open(file_path,'w')
	json.dump(listObj,file_del)

# Index Function
def index(request):
	if request.method=='POST':
		newurl=request.POST['newurl']
#		expirytime=request.POST['expirytime']
#		expirytime=int(expirytime)
		random_word=randomise()
		del_rand_word(random_word)
		add_json_data(random_word,newurl)
		# Send to random link
		rand_link=random_link()
		nexpage='/'+rand_link+"?key={}".format(random_word)
		return redirect(nexpage)
		#After The Time
#		del_json=Timer(expirytime,del_json_data(random_word))
#		del_json.start()
#		add_word=Timer(expirytime,add_rand_word(random_word))
#		add_word.start()
	return render(request,'index.html')
	
# Dynamic Function
def dynamic(request,timeframe):
	module_dir=os.path.dirname(__file__)
	filepath=os.path.join(module_dir,'workpost.json')
	listObj={}
	file=open(filepath,'r')
	listObj=json.load(file)
	if timeframe in listObj:
		return HttpResponsePermanentRedirect(listObj[timeframe])
	else:
		if request.method=='GET':
			key=request.GET.get('key')
			context={
			'random_word':key
			}
		return render(request,'dynamic.html',context)