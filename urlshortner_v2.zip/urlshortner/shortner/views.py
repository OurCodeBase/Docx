from django.shortcuts import render,redirect
from django.http import HttpResponsePermanentRedirect
import datetime
import os
import random
import string
import json

# Create your views here.

# Delete That Random word.
def del_rand_word(del_rand_str):
	module_dir=os.path.dirname(__file__)
	file_path=os.path.join(module_dir,'wordlist.md')
	random_file=open(file_path,'r')
	read_random_word_file=random_file.read()
	random_list=list(map(str,read_random_word_file.split()))
	random_list.remove(del_rand_str)
	add_file=open(file_path,'w')
	for items in random_list:
		add_file.write(items+'\n')

# Randomise Words
def randomise():
	module_dir=os.path.dirname(__file__)
	file_path=os.path.join(module_dir,'wordlist.md')
	random_file=open(file_path,'r')
	read_random_word_file=random_file.read()
	random_list=list(map(str,read_random_word_file.split()))
	random_word=random.choice(random_list)
	return random_word

# Randomise Dynamic Random Urls
def random_link():
	lower=string.ascii_lowercase
	upper=string.ascii_uppercase
	num=string.digits
	all_char=lower+upper+num
	temp=random.sample(all_char,16)
	rand_link="".join(temp)
	return rand_link
	
# Add file to json
def json_data(key,value,expirytime):
	module_dir=os.path.dirname(__file__)
	file_path=os.path.join(module_dir,'workpost.json')
	listObj={}
	json_file=open(file_path,'r')
	listObj=json.load(json_file)
	expirytime=int(expirytime)
	current_time=datetime.datetime.now()
	adding_time=datetime.timedelta(hours=expirytime)
	max_time=current_time+adding_time
	max_time=str(max_time)
	dictionary={"{}".format(key):{"url":"{}".format(value),"expiry":"{}".format(max_time)}}
	listObj=dict(listObj)
	listObj.update(dictionary)
	file_add=open(file_path,'w')
	json.dump(listObj,file_add)

# Index Function
def index(request):
	if request.method=='POST':
		newurl=request.POST['newurl']
		expirytime=request.POST['expirytime']
		newurl=str(newurl)
		http="http"
		if http in newurl:
		    random_word=randomise()
		    del_rand_word(random_word)
		    json_data(random_word,newurl,expirytime)
		    # Send to random link
		    rand_link=random_link()
		    nexpage='/'+rand_link+"?key={}".format(random_word)
		    return redirect(nexpage)
		else:
		    nexpage="/error-bad-url"+"?key={}".format("Your url is not valid !")
		    return redirect(nexpage)
	return render(request,'index.html')
	
# Dynamic Function
def dynamic(request,timeframe):
	module_dir=os.path.dirname(__file__)
	filepath=os.path.join(module_dir,'workpost.json')
	listObj={}
	file=open(filepath,'r')
	listObj=json.load(file)
	if timeframe in listObj:
		return HttpResponsePermanentRedirect(listObj[timeframe]["url"])
	elif "error-bad-url" in timeframe:
	    if request.method=='GET':
	        bad_key=request.GET.get('key')
	        bad_context={
	            'bad_word':bad_key
	        }
	        return render(request,'dynamic.html',bad_context)
	else:
		if request.method=='GET':
			key=request.GET.get('key')
			context={
			'random_word':key
			}
		return render(request,'dynamic.html',context)