import json
import time
import datetime
from dateutil import parser

def add_wordlist(chabi):
    word_file_path="urlshortner/shortner/wordlist.md"
    word_file=open(word_file_path,'r')
    readfile=word_file.read()
    words=list(map(str,readfile.split()))
    words.append(chabi)
    words_add=open(word_file_path,'w')
    for items in words:
                words_add.write(items+'\n')
                
def del_json_data(chabi):
	file_path="urlshortner/shortner/workpost.json"
	listObj_json={}
	json_file_=open(file_path,'r')
	listObj_json=json.load(json_file_)
	del listObj_json["{}".format(chabi)]
	file_del=open(file_path,'w')
	json.dump(listObj_json,file_del)

while True:
    listObj={}
    filepath="urlshortner/shortner/workpost.json"
    json_file=open(filepath,'r')
    listObj=json.load(json_file)
    for key in listObj:
        expiry=listObj[key]["expiry"]
        expiry_date=parser.parse(expiry)
        current_time=datetime.datetime.now()
        if (expiry_date.year==current_time.year and expiry_date.month==current_time.month and expiry_date.day==current_time.day and expiry_date.hour==current_time.hour):
            print("A link is expired !")
            add_wordlist(key)
            del_json_data(key)
            print("Successfully deleted link")
    time.sleep(3600)