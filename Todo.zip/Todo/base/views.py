from django.shortcuts import render,redirect
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate as varify
from django.contrib.auth import login as auth_login
from django.contrib.auth import logout
from django.utils.safestring import mark_safe
# Create your views here.

# Strings
sen_reg_error="<b>Something went wrong !</b><br/>• Use another username <br/>• Choose a new different email."

sen_reg_success="Your account has been successfully created."

sen_reg_pass="<b>Something went wrong !</b><br/>• Your password must have 6 characters <br/>• Make sure your confirm password."

def home(request):
	username=None
	if request.user.is_authenticated:
		username=request.user.username
		context={
			"userid":"Hello "+username,
		}
		return render(request,'index.html',context)
	return render(request,'index.html')
	
def login(request):
	if request.method=="POST":
		username=request.POST['userlog']
		password=request.POST['passlog']
		try:
			user=varify(username=username,password=password)
			if user is not None:
				auth_login(request,user)
				messages.success(request,"Loggin Successfully !")
				return redirect('/')
			else:
				messages.error(request,"Bad Credentials")
		except:
			messages.error(request,"Login Failed !")
	return render(request,'login.html')
	
def register(request):
	if request.method=="POST":
		username=request.POST['uservar']
		email=request.POST['email']
		password1=request.POST['password1']
		password2=request.POST['password2']
		if password1==password2 and len(password1)>=6:
			try:
				myuser=User.objects.create_user(username,email,password1)
				myuser.save()
				messages.success(request,mark_safe(sen_reg_success))
				return redirect('/login')
			except:
				messages.error(request,mark_safe(sen_reg_error))
		else:
			messages.error(request,mark_safe(sen_reg_pass))
	return render(request,'register.html')
	
def remlog(request):
	try:
		logout(request)
		return redirect('/')
		messages.success(request,"Successfully Logged Out !")
	except:
		messages.error(request,"Logout Failed !")