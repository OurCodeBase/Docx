from django.shortcuts import render,redirect
from django.contrib.auth.models import User
from django.contrib import messages
from django.contrib.auth import authenticate as varify
from django.contrib.auth import login as auth_login
from django.contrib.auth import logout
# Create your views here.

def home(request):
	username=None
	if request.user.is_authenticated:
		username=request.user.username
		context={
			"userid":"Hello "+username,
		}
		return render(request,'index.html',context)
	return render(request,'index.html')
	
def login(request):
	if request.method=="POST":
		username=request.POST['userlog']
		password=request.POST['passlog']
		user=varify(username=username,password=password)
		if user is not None:
			auth_login(request,user)
			messages.success(request,"Loggin Successfully !")
		else:
			messages.error(request,"Bad Credentials")
	return render(request,'login.html')
	
def register(request):
	if request.method=="POST":
		username=request.POST['uservar']
		email=request.POST['email']
		password1=request.POST['password1']
		password2=request.POST['password2']
		myuser=User.objects.create_user(username,email,password1)
		myuser.save()
		messages.success(request,"Your account has been successfully created.")
	return render(request,'register.html')
	
def remlog(request):
	try:
		logout(request)
		return redirect('/')
	except:
		messages.success(request,"Logout Failed !")